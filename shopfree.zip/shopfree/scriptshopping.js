//แสดงส่วนของ header
const imageSlider = document.querySelector('.image-slider');
const images = imageSlider.querySelectorAll('.images');
let currentImageIndex = 0;


images[currentImageIndex].style.opacity = '1';

function showNextImage() {
  images[currentImageIndex].style.opacity = '0';
  currentImageIndex = (currentImageIndex + 1) % images.length;
  images[currentImageIndex].style.opacity = '1';
}

setInterval(showNextImage, 1000);



//ส่วนของการคำนวณ
const calcButtons = document.querySelectorAll('.order-button');
const cancelButton = document.getElementById('cancel-button');
const resultElement = document.getElementById('result');
const discountedResultElement = document.getElementById('discounted-result');
let currentTotal = 0;
let buttonClickCount = 0;

calcButtons.forEach(button => {
  button.addEventListener('click', () => {
    if (buttonClickCount < 4) {
      const buttonValue = parseFloat(button.getAttribute('data-price'));
      currentTotal += buttonValue;
      resultElement.textContent = currentTotal.toLocaleString();

      if (currentTotal > 0) {
        const discountedAmount = currentTotal * 0.1;
        const discountedTotal = currentTotal - discountedAmount;
        discountedResultElement.textContent = discountedTotal.toLocaleString();
      }

      buttonClickCount++;

      if (buttonClickCount === 4) {
        calcButtons.forEach(btn => {
          btn.disabled = true;
        });
      }
    }
  });
});

cancelButton.addEventListener('click', () => {
  currentTotal = 0;
  resultElement.textContent = 'ราคา';
  discountedResultElement.textContent = 'ราคาหลังใช้ส่วนลด';
  buttonClickCount = 0;

  calcButtons.forEach(btn => {
    btn.disabled = false;
  });
});
//ส่วนของ นโยบาย
function openPolicyPopup() {
  const popupContent = `
    <html>
    <head>
      <title>นโยบายการสั่งซื้อ</title>
    </head>
    <body>
      <center><h1>นโยบายการสั่งซื้อสินค้า</h1>
      <p><h1>ข้อเสนอพิเศษสำหรับคุณสามารถซื้อของในเว็ปของเราได้ส่วนลด10%</h></p>
      <p><h2>แต่คุณสามารถซื้อได้เพียง 4 ชิ้นเท่านั้น</h2></p>
      <p>หมายเหตุ : นี่คือสินค้า pre order</p>\
      <p>สินค้าจะจัดส่งภายใน 10ปี นี้ </p>
      <p><h1>/////ควรชำระทันที////</h1></p></center>
    </body>
    </html>
  `;

  const popupWindow = window.open('', 'popupPolicyWindow', 'width=500,height=500');
  popupWindow.document.open();
  popupWindow.document.write(popupContent);
  popupWindow.document.close();
}

//ส่วนของที่อยู่

function submitForm() {
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const workplace = document.getElementById('workplace').value;
  const address = document.getElementById('address').value;
  const houseNumber = document.getElementById('houseNumber').value;
  const street = document.getElementById('street').value;
  const province = document.getElementById('province').value;
  const country = document.getElementById('country').value;
  const continent = document.getElementById('continent').value;
  const zipCode = document.getElementById('zipCode').value;
  const phoneNumber = document.getElementById('phoneNumber').value;

  if (!firstName || !lastName || !workplace || !address || !houseNumber || !street ||
      !province || !country || !continent || !zipCode || !phoneNumber) {
    alert('กรุณากรอกข้อมูลให้ครบทุกช่อง');
    return;
  }

  if (!/^\d{10}$/.test(phoneNumber)) {
    alert('เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลัก');
    return;
  }

  if (!/^\d{5}$/.test(zipCode)) {
    alert('รหัสไปรษณีย์ต้องเป็นตัวเลข 5 หลัก');
    return;
  }

  
  alert('ข้อมูลถูกต้องและถูกส่งไปแล้ว');
}
 




