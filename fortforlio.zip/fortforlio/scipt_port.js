
 // ข้อมูลการใช้ชีวิตประจำวัน
var dailyRoutine = {
  labels: ['เล่นเกม', 'อ่านหนังสือ', 'ทำงาน', 'ดูสื่อวิดีโอ', 'นอน', 'อื่นๆ'],
  data: [10, 5, 30, 10, 40, 5], // ใส่ข้อมูลเป็นร้อยละ
};

// สร้างและแสดงกราฟ
function createChart() {
  var ctx = document.getElementById('routineChart').getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar', // ปรับเปลี่ยนเป็น 'line', 'doughnut', 'pie', หรืออื่นๆ ได้
    data: {
      labels: dailyRoutine.labels,
      datasets: [{
        label: 'การใช้ชีวิตประจำวัน (%)',
        data: dailyRoutine.data,
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
        borderWidth: 1,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
        }
      }
    }
  });
}

// เรียกใช้งานการสร้างกราฟ
createChart();
